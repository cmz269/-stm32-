/*
*******************************************
*/
#include "ros/ros.h"
#include <serial/serial.h>
#include <iostream>
#include "std_msgs/String.h"
#include "geometry_msgs/Twist.h"
#include <nav_msgs/Odometry.h>
#include <tf/transform_broadcaster.h>
//创建一个serial类
serial::Serial sp;


//只简单输出前轮的行程和前轮的转角,未涉及坐标转换
float speed_x;//前驱三轮车前轮速度
float turn_z;//前驱三轮车前轮转角
uint8_t i_u;
uint8_t FLAG_USART; 
uint8_t FLAG_US; 
uint16_t count;
uint8_t Flag_start=0;
float x_mid_speed;
float y_mid_speed;
float z_mid_speed;
float z_mid_angle;
float angle_A,angle_B,angle_C,angle_D;
float speed_A,speed_B,speed_C,speed_D;
int size;
float Data1=0,Data2,Data3,Data4,Data5,Data6,Data7,Data8,Data9,Data10,Data11;

void send_data(float data1,float data2,float data3,float data4,float data5,float data6,float data7,float data8,float data9,float data10,float data11,float data12);
void chatterCallback(const geometry_msgs::Twist &msg)//获取键盘控制的回调函数
{
/*四轮四驱*/  
    ROS_INFO("X_linear: [%g]", msg.linear.x);//
    ROS_INFO("Y_linear: [%g]", msg.linear.y);
    ROS_INFO("Z_linear: [%g]", msg.linear.z);
    ROS_INFO("X_angular: [%g]", msg.angular.x);//
    ROS_INFO("Y_angular: [%g]", msg.angular.y);
    ROS_INFO("Z_angular: [%g]", msg.angular.z);
    ROS_INFO("-------------");

    x_mid_speed =msg.linear.x;
    z_mid_speed =msg.linear.z;
    z_mid_angle =msg.angular.z;

    if(x_mid_speed > +1.1)x_mid_speed = +1.1;
    if(x_mid_speed < -1.1)x_mid_speed = -1.1;

    if(z_mid_speed > +1.1)z_mid_speed = +1.1;
    if(z_mid_speed < -1.1)z_mid_speed = -1.1;

    if(z_mid_angle > +1.1)z_mid_angle = +1.1;
    if(z_mid_angle < -1.1)z_mid_angle = -1.1;


            if(x_mid_speed>0 && z_mid_speed==0 && z_mid_angle==0){
			               speed_A= x_mid_speed;
				       speed_B= x_mid_speed; 
				       speed_C= x_mid_speed; 
				       speed_D= x_mid_speed;  
				       angle_A=0;angle_B=0;angle_C=0;angle_D=0;
			        }//前进
       else if(x_mid_speed<0 && z_mid_speed==0 && z_mid_angle==0){
			               speed_A= x_mid_speed;
				       speed_B= x_mid_speed; 
				       speed_C= x_mid_speed; 
				       speed_D= x_mid_speed;  
				       angle_A=0;angle_B=0;angle_C=0;angle_D=0;
			        }//后退

       else if(x_mid_speed==0 && z_mid_speed==0 && z_mid_angle>0){
			               speed_A= z_mid_angle*0.5;
				       speed_B= z_mid_angle*0.5; 
				       speed_C= z_mid_angle*0.5; 
				       speed_D= z_mid_angle*0.5;  
				       angle_A=-90;angle_B=-90;angle_C=-90;angle_D=-90;
			        }//左移
       else if(x_mid_speed==0 && z_mid_speed==0 && z_mid_angle<0){
			               speed_A= z_mid_angle*0.5;
				       speed_B= z_mid_angle*0.5; 
				       speed_C= z_mid_angle*0.5; 
				       speed_D= z_mid_angle*0.5;  
				       angle_A=-90;angle_B=-90;angle_C=-90;angle_D=-90;
			        }//右移

       else if(x_mid_speed==0 && z_mid_speed>0 && z_mid_angle==0){
			               speed_A= z_mid_speed;
				       speed_B= z_mid_speed; 
				       speed_C= z_mid_speed; 
				       speed_D= z_mid_speed;  
				       angle_A=+54.78;angle_B=-54.78;angle_C=+54.78;angle_D=-54.78;
			        }//左自转
       else if(x_mid_speed==0 && z_mid_speed<0 && z_mid_angle==0){
			               speed_A= z_mid_speed;
				       speed_B= z_mid_speed; 
				       speed_C= z_mid_speed; 
				       speed_D= z_mid_speed;  
				       angle_A=+54.78;angle_B=-54.78;angle_C=+54.78;angle_D=-54.78;
			        }//右自转

       else if(x_mid_speed>0 && z_mid_speed==0 && z_mid_angle>0){
			               speed_A= x_mid_speed;
				       speed_B= x_mid_speed; 
				       speed_C= x_mid_speed; 
				       speed_D= x_mid_speed;  
				       angle_A=-45;angle_B=-45;angle_C=-45;angle_D=-45;
			        }//左斜上
       else if(x_mid_speed>0 && z_mid_speed==0 && z_mid_angle<0){
			               speed_A= x_mid_speed;
				       speed_B= x_mid_speed; 
				       speed_C= x_mid_speed; 
				       speed_D= x_mid_speed;  
				       angle_A=+45;angle_B=+45;angle_C=+45;angle_D=+45;
			        }//右斜上
	else if(x_mid_speed<0 && z_mid_speed==0 && z_mid_angle>0){
			               speed_A= x_mid_speed;
				       speed_B= x_mid_speed; 
				       speed_C= x_mid_speed; 
				       speed_D= x_mid_speed;  
				       angle_A=+45;angle_B=+45;angle_C=+45;angle_D=+45;
			        }//左斜下
        else if(x_mid_speed<0 && z_mid_speed==0 && z_mid_angle<0){
			               speed_A= x_mid_speed;
				       speed_B= x_mid_speed; 
				       speed_C= x_mid_speed; 
				       speed_D= x_mid_speed;  
				       angle_A=-45;angle_B=-45;angle_C=-45;angle_D=-45;
			        }//右斜下
  
   if(x_mid_speed>0 && z_mid_speed==0 && z_mid_angle==0)Flag_start=0;
   else Flag_start=1;

/*三轮前轮单驱*/     
//    ROS_INFO("X_speed: [%g]", msg.linear.x);//
//    ROS_INFO("Z_turn: [%g]", msg.linear.z);
//    ROS_INFO("WHEEL_turn: [%g]", msg.angular.z);
//    ROS_INFO("-------------");

//    x_mid_speed =msg.linear.x;
//    z_mid_speed =msg.linear.z;
//    z_mid_angle =msg.angular.z;

//    if(x_mid_speed > +1.1)x_mid_speed = +1.1;
//    if(x_mid_speed < -1.1)x_mid_speed = -1.1;

//    if(z_mid_speed > +1.1)z_mid_speed = +1.1;
//    if(z_mid_speed < -1.1)z_mid_speed = -1.1;

//    if(z_mid_angle > +90)z_mid_angle = +90;
//    if(z_mid_angle < -90)z_mid_angle = -90;

//       if(x_mid_speed>0 && z_mid_speed==0 && z_mid_angle==0){speed_x= x_mid_speed;turn_z=0;}//前进
//  else if(x_mid_speed<0 && z_mid_speed==0 && z_mid_angle==0){speed_x= x_mid_speed;turn_z=0;}//后退

//  else if(x_mid_speed==0 && z_mid_speed>0 && z_mid_angle==0){speed_x= +z_mid_speed;turn_z=+90;}//左自转
//  else if(x_mid_speed==0 && z_mid_speed<0 && z_mid_angle==0){speed_x= +z_mid_speed;turn_z=+90;}//右自转

//  else if(x_mid_speed>0 && z_mid_speed==0 && z_mid_angle>0){speed_x= x_mid_speed;turn_z=z_mid_angle;}//左前转弯
//  else if(x_mid_speed>0 && z_mid_speed==0 && z_mid_angle<0){speed_x= x_mid_speed;turn_z=z_mid_angle;}//右前转弯

//  else if(x_mid_speed<0 && z_mid_speed==0 && z_mid_angle<0){speed_x= x_mid_speed;turn_z=-z_mid_angle;}//左后转弯
//  else if(x_mid_speed<0 && z_mid_speed==0 && z_mid_angle>0){speed_x= x_mid_speed;turn_z=-z_mid_angle;}//右后转弯

//  else if(x_mid_speed==0 && z_mid_speed==0 && z_mid_angle>0){speed_x= 0;turn_z=z_mid_angle;}//纯轮子转动
//  else if(x_mid_speed==0 && z_mid_speed==0 && z_mid_angle<0){speed_x= 0;turn_z=z_mid_angle;}//纯轮子转动
//  
//  if(x_mid_speed==0 && z_mid_speed==0 && z_mid_angle==0)Flag_start=0;
//  else Flag_start=1;
// 
   FLAG_USART=1;

}
typedef unsigned char byte;
float b2f(byte m0, byte m1, byte m2, byte m3)
{
//求符号位
    float sig = 1.;
    if (m0 >=128.)
        sig = -1.;
  
//求阶码
    float jie = 0.;
     if (m0 >=128.)
    {
        jie = m0-128.  ;
    }
    else
    {
        jie = m0;
    }
    jie = jie * 2.;
    if (m1 >=128.)
        jie += 1.;
  
    jie -= 127.;
//求尾码
    float tail = 0.;
    if (m1 >=128.)
        m1 -= 128.;
    tail =  m3 + (m2 + m1 * 256.) * 256.;
    tail  = (tail)/8388608;   //   8388608 = 2^23

    float f = sig * pow(2., jie) * (1+tail);
 
    return f;
}

int main(int argc, char **argv){

    ros::init(argc, argv, "listener");

    ros::NodeHandle np;//为这个进程的节点创建一个句柄

    ros::Subscriber sub = np.subscribe("cmd_vel", 200, chatterCallback);//订阅键盘控制

    ros::init(argc, argv, "odometry_publisher");
    ros::NodeHandle n;
    ros::Publisher odom_pub = n.advertise<nav_msgs::Odometry>("odom", 50);

  tf::TransformBroadcaster odom_broadcaster;

  double x = 0.0;

  double y = 0.0;

  double th = 0.0;

 

  double vx = 0.0;

  double vy = 0.0;

  double vth = 0.0;

 

  ros::Time current_time, last_time;

  current_time = ros::Time::now();

  last_time = ros::Time::now();


   //创建timeout
    serial::Timeout to = serial::Timeout::simpleTimeout(100);
    //设置要打开的串口名称
    sp.setPort("/dev/ttyUSB0");
    //设置串口通信的波特率
    sp.setBaudrate(115200);
    //串口设置timeout
    sp.setTimeout(to);
 
    try
    {
        //打开串口
        sp.open();
    }
    catch(serial::IOException& e)
    {
        ROS_ERROR_STREAM("Unable to open port.");
        return -1;
    }
    
    //判断串口是否打开成功
    if(sp.isOpen())
    {
        ROS_INFO_STREAM("/dev/ttyUSB0 is opened.");

    }
    else
    {
        return -1;
    }   
    for(uint8_t j=0;j<3;j++)send_data(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);  
   ros::Rate loop_rate(50);//设置循环间隔，即代码执行频率 100HZ

   while(ros::ok())
   {
		 
/*三轮前轮单驱*/  
//    current_time = ros::Time::now();//记录当前时间
// 
//    vx  = Data2;//前轮当前线速度 m/s  未转换为X轴速度
//    vy  = 0;//三轮前驱无Y轴速度
//    vth = (Data6/16384.f)*1000*(3.1415926f/180.f);//设备当前Z轴角速度 rad/s

//    //以给定机器人速度的典型方式计算里程计
//    double dt = (current_time - last_time).toSec();

//    double delta_x = (vx * cos(th) - vy * sin(th)) * dt;

//    double delta_y = (vx * sin(th) + vy * cos(th)) * dt;

//    double delta_th = vth * dt;

//      x += delta_x;//X轴速度累积位移 m

//      y += delta_y;//Y轴速度累积位移 m

//      th += delta_th;//Z轴角速度累积求车体朝向角度  rad //存在漂移

//      //因为所有的里程表都是6自由度的，所以我们需要一个由偏航创建的四元数
//      geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromYaw(th);

//      //首先，我们将通过tf发布转换

//      geometry_msgs::TransformStamped odom_trans;

//      odom_trans.header.stamp = current_time;

//      odom_trans.header.frame_id = "odom";

//      odom_trans.child_frame_id = "base_link";

//      odom_trans.transform.translation.x = x;

//      odom_trans.transform.translation.y = y;

//      odom_trans.transform.translation.z = 0.0;

//      odom_trans.transform.rotation = odom_quat;

//      //发送转换

//      odom_broadcaster.sendTransform(odom_trans);


//       //接下来，我们将通过ROS发布里程计信息

//       nav_msgs::Odometry odom;

//       odom.header.stamp = current_time;

//       odom.header.frame_id = "odom";


//       //设置位置
//       odom.pose.pose.position.x = x;

//       odom.pose.pose.position.y = y;

//       odom.pose.pose.position.z = th;

//       odom.pose.pose.orientation = odom_quat;


//       //设定速度
//       odom.child_frame_id = "base_link";

//       odom.twist.twist.linear.x = vx;

//       odom.twist.twist.linear.y = vy;

//       odom.twist.twist.angular.z = vth;


//       //发布消息
//       odom_pub.publish(odom);

//       last_time = current_time;//保存为上次时间


        ros::spinOnce();//执行回调处理函数，完后继续往下执行
	if(FLAG_USART==1){			
		/*四轮四驱*/				
        //发送指令控制电机运行 其中Flag_start是控制电机启动和停止的（1/0 启动/停止） ABCD四轮的目标转角 deg/s ABCD四轮的目标线速度 m/s   
        send_data(Flag_start, angle_A, angle_B, angle_C, angle_D, speed_A, speed_B, speed_C, speed_D, 0, 0, 0);
        //获取下位机的数据				
               size_t n = sp.available();//获取缓冲区内的字节数
               if(n>0 )
               {
                   uint8_t buffer[54];
                   sp.read(buffer, n);//读出数据  

                   if(buffer[0]==0XAA && buffer[1]==0XAA && buffer[2]==0XF1)
                   {               
                         uint8_t sum; 
	                 for(uint8_t j=0;j<52;j++)sum+=buffer[j];    //计算校验和	
                         if(sum==buffer[52])
                         {	

	                     Data1=  b2f(buffer[4],  buffer[5],  buffer[6],  buffer[7]); //电机启动停止控制位（1/0 启动/停止）
	                     Data2=  b2f(buffer[8],  buffer[9],  buffer[10], buffer[11]);//A轮转向角 deg/s 
	                     Data3=  b2f(buffer[12], buffer[13], buffer[14], buffer[15]);//B轮转向角 deg/s 
	                     Data4=  b2f(buffer[16], buffer[17], buffer[18], buffer[19]);//C轮转向角 deg/s 	
	                     Data5=  b2f(buffer[20], buffer[21], buffer[22], buffer[23]);//D轮转向角 deg/s 	
	                     Data6=  b2f(buffer[24], buffer[25], buffer[26], buffer[27]);//A轮线速度 m/s 	
	                     Data7=  b2f(buffer[28], buffer[29], buffer[30], buffer[31]);//B轮线速度 m/s 
	                     Data8=  b2f(buffer[32], buffer[33], buffer[34], buffer[35]);//C轮线速度 m/s 	
	                     Data9=  b2f(buffer[36], buffer[37], buffer[38], buffer[39]);//D轮线速度 m/s 	
		             Data10= b2f(buffer[40], buffer[41], buffer[42], buffer[43]);//Z轴角速度 gyro_Yaw deg/s 
                             Data11= b2f(buffer[44], buffer[45], buffer[46], buffer[47]);//电池电压
												 
                       //该位预留
			              				
	                  }sum =0;
 			 memset(buffer, 0, sizeof(uint8_t)*54);								
                    }

		if(Data1==1)
                  ROS_INFO("Flag_start: ON");//下位机电机启动/停止标志，1启动，0停止
                else
                  ROS_INFO("Flag_start: OFF");//下位机电机启动/停止标志，1启动，0停止

                  ROS_INFO("Current_angle_A: [%f deg/s]", Data2); //A轮转向角 deg/s 
                  ROS_INFO("Current_angle_B: [%f deg/s]", Data3); //B轮转向角 deg/s 
                  ROS_INFO("Current_angle_C: [%f deg/s]", Data4); //C轮转向角 deg/s 
                  ROS_INFO("Current_angle_D: [%f deg/s]", Data5); //D轮转向角 deg/s 				 

                  ROS_INFO("Current_linear_A: [%f m/s]", Data6); //A轮线速度 m/s
                  ROS_INFO("Current_linear_B: [%f m/s]", Data7); //B轮线速度 m/s 
                  ROS_INFO("Current_linear_C: [%f m/s]", Data8); //C轮线速度 m/s 
                  ROS_INFO("Current_linear_D: [%f m/s]", Data9); //D轮线速度 m/s

                  ROS_INFO("gyro_Yaw: [%f deg/s]", Data10); //Z轴角速度 gyro_Yaw deg/s 
                  ROS_INFO("Voltage: [%f V]", Data11/100); // 电池电压
                  ROS_INFO("-----------------------"); 
																		
                }
		}
         FLAG_USART=0;					 
//  /*三轮前轮单驱*/								 
//        //发送指令控制电机运行 其中Flag_start是控制电机启动和停止的（1/0 启动/停止） speed_x为前轮线速度 turn_z为前轮转角    
//        send_data(Flag_start, speed_x, 0, turn_z, 0, 0, 0, 0, 0, 0, 0, 0);//电机(启动/停止)(1/0)，前轮速度 m/s，0，前轮转角 °/s .
//        //获取下位机的数据				
//               size_t n = sp.available();//获取缓冲区内的字节数
//               if(n>0 )
//               {

//                   uint8_t buffer[54];
//                   sp.read(buffer, n);//读出数据  

//                   if(buffer[0]==0XAA && buffer[1]==0XAA && buffer[2]==0XF1)
//                   {               
//                         uint8_t sum; 
//	                 for(uint8_t j=0;j<52;j++)sum+=buffer[j];    //计算校验和	
//                         if(sum==buffer[52])
//                         {	
//												 
//	                     Data1=  b2f(buffer[4],  buffer[5],  buffer[6],  buffer[7]); //电机启动停止控制位（1/0 启动/停止）
//	                     Data2=  b2f(buffer[8],  buffer[9],  buffer[10], buffer[11]);//前轮线速度 
//	                     Data3=  b2f(buffer[12], buffer[13], buffer[14], buffer[15]);//前轮转角
//	                     Data4=  b2f(buffer[16], buffer[17], buffer[18], buffer[19]);//绕X轴角速度 gyro_Roll 原始数值	
//	                     Data5=  b2f(buffer[20], buffer[21], buffer[22], buffer[23]);//绕Y轴角速度 gyro_Pitch 原始数值	
//	                     Data6=  b2f(buffer[24], buffer[25], buffer[26], buffer[27]);//绕Z轴角速度 gyro_Yaw 原始数值	
//	                     Data7=  b2f(buffer[28], buffer[29], buffer[30], buffer[31]);//X轴加速度 accel_x 原始数值	
//	                     Data8=  b2f(buffer[32], buffer[33], buffer[34], buffer[35]);//Y轴加速度 accel_y 原始数值	
//	                     Data9=  b2f(buffer[36], buffer[37], buffer[38], buffer[39]);//Z轴加速度 accel_z 原始数值	
//		                   Data10= b2f(buffer[40], buffer[41], buffer[42], buffer[43]); //Yaw Z轴角度
//		                   Data11= b2f(buffer[44], buffer[45], buffer[46], buffer[47]); //电池电压
//			              				
//	                  }sum =0;
// 			             memset(buffer, 0, sizeof(uint8_t)*54);								
//                    }
//                  if(Data1==1)
//                   ROS_INFO("Flag_start: ON");//下位机电机启动/停止标志，1启动，0停止
//                  else
//                  ROS_INFO("Flag_start: OFF");//下位机电机启动/停止标志，1启动，0停止

//                  ROS_INFO("Current_linear_x: [%f m/s]", Data2);//前轮当前线速度 
//                  ROS_INFO("Current_angle_z: [%f deg/s]", Data3); //前轮当前转角

//                  ROS_INFO("gyro_Roll: [%g ]", Data4); //车体绕X轴当前角速度 原始数值	
//                  ROS_INFO("gyro_Pitch: [%g ]", Data5); //车体绕Y轴当前角速度 原始数值	
//                  ROS_INFO("gyro_Yaw: [%g ", Data6); //车体绕Z轴当前角速度 原始数值

//                  ROS_INFO("accel_x: [%g ]", Data7); //车体X轴当前加速度 原始数值	
//                  ROS_INFO("accel_y: [%g ]", Data8); //车体Y轴当前加速度 原始数值	
//                  ROS_INFO("accel_z: [%g ", Data9); //车体Z轴当前加速度 原始数值	

//                  ROS_INFO("Yaw: [%f deg]", Data10); //车体Z轴当前角度 deg
//                  ROS_INFO("Voltage: [%f V]", Data11/100); // 电池电压
//                  ROS_INFO("-----------------------");  
//										
//                }


        Data1=0;
        loop_rate.sleep();//循环延时时间
   }
    


   for(uint8_t j=0;j<3;j++)send_data(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
   //关闭串口
   sp.close();  

    return 0;
}


//************************发送12个数据**************************// 
void send_data(float data1,float data2,float data3,float data4,float data5,float data6,float data7,float data8,float data9,float data10,float data11,float data12)
{
    uint8_t tbuf[53];
    unsigned char *p;
    p=(unsigned char *)&data1;
    tbuf[4]=(unsigned char)(*(p+3));
    tbuf[5]=(unsigned char)(*(p+2));
    tbuf[6]=(unsigned char)(*(p+1));
    tbuf[7]=(unsigned char)(*(p+0));

    p=(unsigned char *)&data2;
    tbuf[8]=(unsigned char)(*(p+3));
    tbuf[9]=(unsigned char)(*(p+2));
    tbuf[10]=(unsigned char)(*(p+1));
    tbuf[11]=(unsigned char)(*(p+0));
     
    p=(unsigned char *)&data3;
    tbuf[12]=(unsigned char)(*(p+3));
    tbuf[13]=(unsigned char)(*(p+2));
    tbuf[14]=(unsigned char)(*(p+1));
    tbuf[15]=(unsigned char)(*(p+0));
	
    p=(unsigned char *)&data4;
    tbuf[16]=(unsigned char)(*(p+3));
    tbuf[17]=(unsigned char)(*(p+2));
    tbuf[18]=(unsigned char)(*(p+1));
    tbuf[19]=(unsigned char)(*(p+0));
		
    p=(unsigned char *)&data5;
    tbuf[20]=(unsigned char)(*(p+3));
    tbuf[21]=(unsigned char)(*(p+2));
    tbuf[22]=(unsigned char)(*(p+1));
    tbuf[23]=(unsigned char)(*(p+0));
     
    p=(unsigned char *)&data6;
    tbuf[24]=(unsigned char)(*(p+3));
    tbuf[25]=(unsigned char)(*(p+2));
    tbuf[26]=(unsigned char)(*(p+1));
    tbuf[27]=(unsigned char)(*(p+0));
		
    p=(unsigned char *)&data7;
    tbuf[28]=(unsigned char)(*(p+3));
    tbuf[29]=(unsigned char)(*(p+2));
    tbuf[30]=(unsigned char)(*(p+1));
    tbuf[31]=(unsigned char)(*(p+0));
     
    p=(unsigned char *)&data8;
    tbuf[32]=(unsigned char)(*(p+3));
    tbuf[33]=(unsigned char)(*(p+2));
    tbuf[34]=(unsigned char)(*(p+1));
    tbuf[35]=(unsigned char)(*(p+0));
     
    p=(unsigned char *)&data9;
    tbuf[36]=(unsigned char)(*(p+3));
    tbuf[37]=(unsigned char)(*(p+2));
    tbuf[38]=(unsigned char)(*(p+1));
    tbuf[39]=(unsigned char)(*(p+0));
	
    p=(unsigned char *)&data10;
    tbuf[40]=(unsigned char)(*(p+3));
    tbuf[41]=(unsigned char)(*(p+2));
    tbuf[42]=(unsigned char)(*(p+1));
    tbuf[43]=(unsigned char)(*(p+0));
		
    p=(unsigned char *)&data11;
    tbuf[44]=(unsigned char)(*(p+3));
    tbuf[45]=(unsigned char)(*(p+2));
    tbuf[46]=(unsigned char)(*(p+1));
    tbuf[47]=(unsigned char)(*(p+0));
     
    p=(unsigned char *)&data12;
    tbuf[48]=(unsigned char)(*(p+3));
    tbuf[49]=(unsigned char)(*(p+2));
    tbuf[50]=(unsigned char)(*(p+1));
    tbuf[51]=(unsigned char)(*(p+0));
		
//fun:功能字 0XA0~0XAF
//data:数据缓存区，48字节
//len:data区有效数据个数


    uint8_t len=48;

    tbuf[len+4]=0;  //校验位置零
    tbuf[0]=0XAA;   //帧头
    tbuf[1]=0XAA;   //帧头
    tbuf[2]=0XF1;    //功能字
    tbuf[3]=len;    //数据长度
    for(uint8_t i=0;i<len+4;i++)tbuf[len+4]+=tbuf[i]; //计算和校验
    
  try
  {
    sp.write(tbuf, len+5);//发送数据下位机

  }
  catch (serial::IOException& e)   
  {
    ROS_ERROR_STREAM("Unable to send data through serial port"); //如果发送数据失败，打印错误信息
  }
}  

