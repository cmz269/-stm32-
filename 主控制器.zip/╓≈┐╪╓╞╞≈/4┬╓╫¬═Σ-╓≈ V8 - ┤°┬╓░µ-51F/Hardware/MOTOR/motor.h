#ifndef __MOTOR_H
#define __MOTOR_H
#include <sys.h>	 
#define PWMA   TIM8->CCR1  
#define PWMB   TIM8->CCR2 
#define PWMC   TIM8->CCR3 
#define PWMD   TIM8->CCR4

#define PWME   TIM1->CCR1 
#define PWMF   TIM1->CCR4
#define INA   PAout(5)  
#define INB   PAout(4)   
#define INC   PCout(4)
#define IND   PBout(15) 
#define EN    PBout(14)  
void Motor_PWM_Init(u16 arr,u16 psc);
void Steering_engine_PWM_Init(u16 arr,u16 psc);
#endif
